using System.Collections;
using UnityEngine;
using TMPro;

/// <summary>
/// Attach to the bench GameObject.
/// - Player deve ter tag "Player" e componente Rigidbody
/// - sitPoint: Transform filho do banco indicando onde o player senta
/// - promptUI: Canvas filho do banco (World Space)
/// </summary>
public class BenchInteraction : MonoBehaviour
{
    // ─── Estado ──────────────────────────────────────────────────────────────
    private enum State { Standing, Sitting, Transitioning }
    private State _state = State.Standing;

    // ─── Inspector ───────────────────────────────────────────────────────────
    [Header("Sit Point")]
    [Tooltip("Transform filho do banco — posicione onde o player vai sentar")]
    public Transform sitPoint;

    [Header("Distância & Offset ao Levantar")]
    public float interactionRadius = 2.5f;
    [Tooltip("Offset local a partir do sitPoint quando o player levanta. Z = para frente do banco")]
    public Vector3 standOffset = new Vector3(0f, 0f, 0.8f);

    [Header("Duração das Transições")]
    public float sitDuration   = 0.45f;
    public float standDuration = 0.35f;

    [Header("Câmera (opcional)")]
    public Vector3 sittingCameraLocalOffset = new Vector3(0f, 1.6f, 0.3f);
    public float   cameraLerpSpeed          = 8f;

    [Header("Animação")]
    [Tooltip("Nome do bool no Animator. Deixe em branco se não tiver animação")]
    public string sitBoolName = "IsSitting";

    [Header("Prompt UI")]
    [Tooltip("Canvas World Space filho do banco")]
    public GameObject promptUI;
    public TextMeshProUGUI promptText;
    public string sitMessage   = "Pressione E para Sentar";
    public string standMessage = "Pressione E para Levantar";
    public bool   billboardPrompt = true;

    // ─── Refs privadas ───────────────────────────────────────────────────────
    private Transform _player;
    private Rigidbody _rb;
    private Animator  _animator;
    private Camera    _cam;

    private Vector3    _camDefaultLocal;
    private Quaternion _camDefaultLocalRot;
    private Vector3    _camTarget;
    private Quaternion _camTargetRot;

    private Coroutine _routine;

    // ─── Unity ───────────────────────────────────────────────────────────────
    private void Start()
    {
        _cam = Camera.main;
        if (_cam != null)
        {
            _camDefaultLocal    = _cam.transform.localPosition;
            _camDefaultLocalRot = _cam.transform.localRotation;
        }
        _camTarget    = _camDefaultLocal;
        _camTargetRot = _camDefaultLocalRot;

        // Prompt começa desligado — NÃO mexer no transform, é filho do banco
        if (promptUI != null)
            promptUI.SetActive(false);

        SetPromptText(sitMessage);
    }

    private void Update()
    {
        if (_player == null)
        {
            TryFindPlayer();
            return;
        }

        // Trava posição/rotação enquanto sentado
        if (_state == State.Sitting)
        {
            _rb.MovePosition(sitPoint.position);
            _rb.linearVelocity  = Vector3.zero;
            _rb.angularVelocity = Vector3.zero;
        }

        // ── Distância e prompt ──
        Vector3 refPoint = sitPoint != null ? sitPoint.position : transform.position;
        float   dist     = Vector3.Distance(refPoint, _player.position);
        bool    inRange  = dist <= interactionRadius;
        bool    showUI   = inRange && _state != State.Transitioning;

        if (promptUI != null && promptUI.activeSelf != showUI)
            promptUI.SetActive(showUI);

        if (showUI && billboardPrompt && _cam != null)
        {
            promptUI.transform.LookAt(
                promptUI.transform.position + _cam.transform.rotation * Vector3.forward,
                _cam.transform.rotation * Vector3.up);
        }

        // ── Input — suporta New e Legacy Input System ──
        bool pressedE = false;

#if ENABLE_INPUT_SYSTEM
        var keyboard = UnityEngine.InputSystem.Keyboard.current;
        if (keyboard != null)
            pressedE = keyboard.eKey.wasPressedThisFrame;
#endif

#if ENABLE_LEGACY_INPUT_MANAGER
        pressedE = pressedE || Input.GetKeyDown(KeyCode.E);
#endif

        if (inRange && _state != State.Transitioning && pressedE)
        {
            if (_state == State.Standing)
                StartTransition(SitDownRoutine());
            else
                StartTransition(StandUpRoutine());
        }

        // ── Camera lerp ──
        if (_cam != null && _cam.transform.parent != null)
        {
            float k = 1f - Mathf.Exp(-cameraLerpSpeed * Time.deltaTime);
            _cam.transform.localPosition = Vector3.Lerp(_cam.transform.localPosition, _camTarget, k);
            _cam.transform.localRotation = Quaternion.Slerp(_cam.transform.localRotation, _camTargetRot, k);
        }
    }

    // ─── Transições ──────────────────────────────────────────────────────────
    private void StartTransition(IEnumerator routine)
    {
        if (_routine != null) StopCoroutine(_routine);
        _routine = StartCoroutine(routine);
    }

    private IEnumerator SitDownRoutine()
    {
        if (sitPoint == null)
        {
            Debug.LogError("[BenchInteraction] sitPoint não atribuído no Inspector!", this);
            _state = State.Standing;
            yield break;
        }

        _state = State.Transitioning;
        if (promptUI != null) promptUI.SetActive(false);

        // Desativa física do player
        FreezeRigidbody(true);
        DisablePlayerMovement(true);
        yield return null; // 1 frame de margem

        // Anima player até o sitPoint
        Vector3    startPos = _player.position;
        Quaternion startRot = _player.rotation;

        _camTarget    = sittingCameraLocalOffset;
        _camTargetRot = Quaternion.identity;

        yield return LerpPlayer(startPos, sitPoint.position, startRot, sitPoint.rotation, sitDuration);

        // Garante posição exata
        _rb.MovePosition(sitPoint.position);
        _player.rotation = sitPoint.rotation;

        SetAnimSitting(true);
        _state = State.Sitting;
        SetPromptText(standMessage);
        _routine = null;
    }

    private IEnumerator StandUpRoutine()
    {
        _state = State.Transitioning;
        if (promptUI != null) promptUI.SetActive(false);
        SetAnimSitting(false);

        yield return null; // 1 frame de margem

        // Posição de destino (à frente do banco)
        Vector3 standTarget = sitPoint.position
            + sitPoint.forward * standOffset.z
            + sitPoint.up      * standOffset.y
            + sitPoint.right   * standOffset.x;

        Vector3    startPos = _player.position;
        Quaternion startRot = _player.rotation;
        Quaternion endRot   = Quaternion.LookRotation(sitPoint.forward, Vector3.up);

        _camTarget    = _camDefaultLocal;
        _camTargetRot = _camDefaultLocalRot;

        yield return LerpPlayer(startPos, standTarget, startRot, endRot, standDuration);

        _rb.MovePosition(standTarget);
        _player.rotation = endRot;

        // Reativa física e movimento
        FreezeRigidbody(false);
        DisablePlayerMovement(false);

        _state = State.Standing;
        SetPromptText(sitMessage);
        _routine = null;
    }

    private IEnumerator LerpPlayer(Vector3 fromPos, Vector3 toPos, Quaternion fromRot, Quaternion toRot, float duration)
    {
        float elapsed = 0f;
        while (elapsed < duration)
        {
            elapsed += Time.deltaTime;
            float t = EaseInOut(Mathf.Clamp01(elapsed / duration));
            _rb.MovePosition(Vector3.Lerp(fromPos, toPos, t));
            _player.rotation = Quaternion.Slerp(fromRot, toRot, t);
            yield return new WaitForFixedUpdate();
        }
    }

    // ─── Rigidbody helpers ───────────────────────────────────────────────────
    private void FreezeRigidbody(bool freeze)
    {
        if (_rb == null) return;
        _rb.isKinematic = freeze;
        if (freeze)
        {
            _rb.linearVelocity  = Vector3.zero;
            _rb.angularVelocity = Vector3.zero;
        }
    }

    /// <summary>
    /// Desativa qualquer MonoBehaviour de movimento no player.
    /// Procura por scripts com "Movement", "Controller" ou "Motor" no nome.
    /// </summary>
    private void DisablePlayerMovement(bool disable)
    {
        if (_player == null) return;

        foreach (var mb in _player.GetComponents<MonoBehaviour>())
        {
            if (mb == null || mb == this) continue;
            string typeName = mb.GetType().Name;
            if (typeName.Contains("Movement") || typeName.Contains("Controller") || typeName.Contains("Motor"))
                mb.enabled = !disable;
        }
    }

    // ─── Utilidades ──────────────────────────────────────────────────────────
    private static float EaseInOut(float t) => t * t * (3f - 2f * t);

    private void SetAnimSitting(bool sitting)
    {
        if (_animator != null && !string.IsNullOrEmpty(sitBoolName))
            _animator.SetBool(sitBoolName, sitting);
    }

    private void SetPromptText(string msg)
    {
        if (promptText != null) promptText.text = msg;
    }

    private void TryFindPlayer()
    {
        GameObject go = GameObject.FindGameObjectWithTag("Player");
        if (go == null) return;

        _player   = go.transform;
        _rb       = go.GetComponent<Rigidbody>();
        _animator = go.GetComponentInChildren<Animator>();

        if (_rb == null)
            Debug.LogWarning("[BenchInteraction] Player não tem Rigidbody! Adicione um Rigidbody ao player.", this);
    }

    // ─── Gizmos ──────────────────────────────────────────────────────────────
    private void OnDrawGizmosSelected()
    {
        Vector3 center = sitPoint != null ? sitPoint.position : transform.position;

        Gizmos.color = Color.cyan;
        Gizmos.DrawWireSphere(center, interactionRadius);

        if (sitPoint != null)
        {
            Gizmos.color = Color.green;
            Vector3 sp = sitPoint.position
                + sitPoint.forward * standOffset.z
                + sitPoint.up      * standOffset.y;
            Gizmos.DrawSphere(sp, 0.12f);
            Gizmos.DrawLine(sitPoint.position, sp);
        }
    }
}